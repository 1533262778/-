package com.example.dypkscore;

import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    // 缓存最新解析到的左右精确比分，用于 UI 层兜底替换
    private static volatile long sLatestLeftScore = -1L;
    private static volatile long sLatestRightScore = -1L;
    private static final Map<String, Long> sFuzzyToExactMap = new ConcurrentHashMap<>();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!"com.ss.android.ugc.aweme".equals(lpparam.packageName)) {
            return;
        }

        // 1. 拦截 TextView.setText：自动映射精确分值 + 动态缩放字号防止 7 位数以上被截断为 "..."
        hookTextViewForPkScore();

        // 2. 拦截 ClassLoader 加载：针对 40.7.0 动态挂载的 Live 插件包与 Battle 数据模型进行自适应 Hook
        hookDynamicBattleClasses(lpparam.classLoader);
    }

    private void hookTextViewForPkScore() {
        XposedHelpers.findAndHookMethod(
                TextView.class,
                "setText",
                CharSequence.class,
                TextView.BufferType.class,
                boolean.class,
                int.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        CharSequence cs = (CharSequence) param.args[0];
                        if (cs == null) return;
                        String text = cs.toString().trim();

                        // 快速过滤：仅处理包含 "万"、"w"、"W" 或大于等于 7 位纯数字的文本
                        boolean isAbbreviated = (text.contains("万") || text.contains("w") || text.contains("W")) && text.length() <= 10;
                        if (!isAbbreviated && text.length() < 7) return;

                        TextView tv = (TextView) param.thisObject;
                        if (!isPkScoreTextView(tv)) return;

                        // 如果命中缓存中的缩略词映射，直接替换为精确数值
                        if (isAbbreviated) {
                            Long exact = matchExactScore(text);
                            if (exact != null && exact >= 1_000_000L) {
                                String formatted = String.format(Locale.US, "%,d", exact);
                                param.args[0] = formatted;
                                text = formatted;
                            }
                        }

                        // 针对百万（7位+）或千万级（8位+）比分自动微调字号、关闭省略号截断
                        if (text.length() >= 7) {
                            tv.setSingleLine(true);
                            tv.setEllipsize(null);
                            float targetSp = text.length() >= 10 ? 8.5f : (text.length() >= 8 ? 9.5f : 10.5f);
                            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, targetSp);
                        }
                    }
                }
        );
    }

    private boolean isPkScoreTextView(TextView tv) {
        try {
            int id = tv.getId();
            if (id != View.NO_ID && tv.getResources() != null) {
                String entryName = tv.getResources().getResourceEntryName(id).toLowerCase(Locale.ROOT);
                if (entryName.contains("battle") || entryName.contains("pk") || entryName.contains("score")
                        || entryName.contains("left_text") || entryName.contains("right_text")) {
                    return true;
                }
            }
            // 向上检查父容器类名或 ID 特征（兼容混淆及动态创建的 View）
            View current = tv;
            for (int i = 0; i < 4; i++) {
                if (!(current.getParent() instanceof View)) break;
                current = (View) current.getParent();
                String clsName = current.getClass().getName().toLowerCase(Locale.ROOT);
                if (clsName.contains("battle") || clsName.contains("pk") || clsName.contains("interact")) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private Long matchExactScore(String fuzzyText) {
        Long cached = sFuzzyToExactMap.get(fuzzyText);
        if (cached != null) return cached;

        // 根据数值近似度匹配最新左/右精确分（例如 "105.2万" 匹配 1052341）
        try {
            String numPart = fuzzyText.replace("万", "").replace("w", "").replace("W", "").replace("+", "").trim();
            double approxWan = Double.parseDouble(numPart);
            long approxVal = (long) (approxWan * 10000);

            if (sLatestLeftScore >= 1_000_000L && Math.abs(sLatestLeftScore - approxVal) < 15000L) {
                return sLatestLeftScore;
            }
            if (sLatestRightScore >= 1_000_000L && Math.abs(sLatestRightScore - approxVal) < 15000L) {
                return sLatestRightScore;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private void hookDynamicBattleClasses(ClassLoader baseClassLoader) {
        // 拦截所有类加载或对象构造，自动识别抖音 40.7.0 中的 BattleScore / BattleUserArmy 模型
        XposedBridge.hookAllMethods(ClassLoader.class, "loadClass", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Class<?> cls = (Class<?>) param.getResult();
                if (cls == null) return;
                String name = cls.getName();

                // 锁定抖音直播连麦 PK 相关包路径
                if (name.startsWith("com.bytedance.android.live.liveinteract")
                        || name.startsWith("com.bytedance.android.livesdk.model.message.battle")
                        || name.startsWith("com.bytedance.android.livesdkapi.depend.model.live.battle")) {
                    inspectAndHookBattleModel(cls);
                }
            }
        });
    }

    private static final Map<String, Boolean> sHookedClasses = new ConcurrentHashMap<>();

    private void inspectAndHookBattleModel(final Class<?> cls) {
        String clsName = cls.getName();
        if (sHookedClasses.putIfAbsent(clsName, Boolean.TRUE) != null) {
            return;
        }

        try {
            Field[] fields = cls.getDeclaredFields();
            boolean hasLongScore = false;
            boolean hasStringScore = false;

            for (Field f : fields) {
                Class<?> type = f.getType();
                if (type == long.class || type == Long.class) hasLongScore = true;
                if (type == String.class) hasStringScore = true;
            }

            // 命中同时包含 long 分数与 String 缩略文本的 PK 数据模型类
            if (hasLongScore && hasStringScore) {
                for (Method m : cls.getDeclaredMethods()) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            Object obj = param.thisObject;
                            if (obj == null) return;
                            syncExactScoreFields(obj);
                        }
                    });
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void syncExactScoreFields(Object model) {
        try {
            Field[] fields = model.getClass().getDeclaredFields();
            long candidateScore = -1L;

            // 1. 提取大于等于 100 万的真实 long 分值
            for (Field f : fields) {
                f.setAccessible(true);
                String fName = f.getName().toLowerCase(Locale.ROOT);
                if (f.getType() == long.class || f.getType() == Long.class) {
                    Object val = f.get(model);
                    if (val instanceof Number) {
                        long v = ((Number) val).longValue();
                        // PK 常见有效分值范围：100 万 ~ 100 亿（排除毫秒时间戳或 roomId）
                        if (v >= 1_000_000L && v < 10_000_000_000L && !fName.contains("id") && !fName.contains("time")) {
                            candidateScore = v;
                            if (sLatestLeftScore != v) {
                                sLatestRightScore = sLatestLeftScore;
                                sLatestLeftScore = v;
                            }
                            break;
                        }
                    }
                }
            }

            if (candidateScore < 1_000_000L) return;

            // 2. 将同对象内带 "万" 或 "w" 的缩略字符串字段直接覆写为精确数值
            String exactStr = String.format(Locale.US, "%,d", candidateScore);
            for (Field f : fields) {
                if (f.getType() == String.class) {
                    f.setAccessible(true);
                    String strVal = (String) f.get(model);
                    if (strVal != null && (strVal.contains("万") || strVal.contains("w") || strVal.contains("W"))) {
                        sFuzzyToExactMap.put(strVal.trim(), candidateScore);
                        f.set(model, exactStr);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }
}
